"use strict";
exports.id = 479;
exports.ids = [479];
exports.modules = {

/***/ 5136:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/menu.4eff5f04.png","height":40,"width":40,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAARVBMVEUpLDEoLDMoLDEnLDIoKzMoLDMoLDEnLDIoLDEnLDEpLTEoLDIoLDEoLDMoLDEoLDIoLDEoLDIoLDEoLDEoLTEoLTEoLDEtw3HJAAAAF3RSTlMAAAAAAAICAgcHCgoKDw8oKCkpPD0+PiU7SZ0AAAA6SURBVHjaHcnJAYAgDATATVQED64A/ZfKwnwHIifJgevfbrzWW+v2wadCKcDnSjngsUEsFzeHRaE6AWliAubO5PaqAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 5479:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Footer_Footer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5537);
/* harmony import */ var _Navbar_Navbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6114);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Navbar_Navbar__WEBPACK_IMPORTED_MODULE_3__]);
_Navbar_Navbar__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function AppLayout({ children  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Navbar_Navbar__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                className: "min-h-screen",
                children: children
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Footer_Footer__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppLayout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5537:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Footer_Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/icons/copyright.png
/* harmony default export */ const copyright = ({"src":"/_next/static/media/copyright.bb9bc420.png","height":24,"width":24,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAmklEQVR42k2OQQvCMAyFe3Y9i+Ddpq6dS/wfQ+l1KsgKnpTeZb/dV9eNBT54eXlNquYiJwGM5DjTqXVZzwlmNMdWE4DureM0DZ10MG5Zk+cX9HvyeYAO6r/Snjbk5YnAhWreH+q2sl62mH1VvmscV2geCF1tIzsE9RJAE0AsayP0p5zrl8+iSeBumrM2XvCaB5DUunIajIUw+z+ZuCgIxOcgtAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./components/layout/LogoComponent.tsx + 1 modules
var LogoComponent = __webpack_require__(9600);
;// CONCATENATED MODULE: ./public/icons/location.png
/* harmony default export */ const icons_location = ({"src":"/_next/static/media/location.6507b9f6.png","height":21,"width":18,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAAlElEQVR42mMAgfIHuwsqHu5+Xv5w9//yB7vuA/nxMIkSkGDFAxDe9bPi4a7/5UA2UCyWAch5BVQNkuiufLBbFMhfUPEQJLnrAgOQ8QckCcReIJOAJsRCjX8C4twCqoLatasfqPgJ1IpDDEAirwIkCbIXogOGA0AmgRQsB0lC7QbRfQwwUHlvNytQcApQ5y0g3QwTBwB3jogVpizvoAAAAABJRU5ErkJggg==","blurWidth":7,"blurHeight":8});
;// CONCATENATED MODULE: ./public/icons/email.png
/* harmony default export */ const email = ({"src":"/_next/static/media/email.22799a07.png","height":24,"width":24,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAiElEQVR42oWPuxHCMBAFldvlYQJcyF0TfGIYqIORIHXqEDJOlYh9dgHWzOpudvROUtpcHrn3KDfq12uZhEX5WOSHxbNLXvMe2ZCBbFZzw/1UYUikDzQ6cGLKhf5Mf8Q3GJM2D6UWUeANSotRV+zWKyQAHJgihmTx6kjckTNiYpoeOlOv+H7zl387+ISaT+uXEQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/icons/call.png
/* harmony default export */ const call = ({"src":"/_next/static/media/call.a5e9008c.png","height":24,"width":24,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAoElEQVR42mMAgfKHu23LHu6SgrB3MTFAAVRyj1HFw93/yx/sOlB8fw8LWOzBbka4AqBkJFQBCFuBxR7sZi1/sAeiqOrhbiGggndAyYcl93azoZq+m4kBomNXBFAX0ITdnVAT7MtvH2eCqtrJBLU3D+jAOUB8EaQYiA8CTZCBumMXC9QkXyD+CFIAdZM1smNZwSbd28EDVBAJlNRjYGBgAAAEi2Wrvag0SgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/icons/facebook.png
/* harmony default export */ const facebook = ({"src":"/_next/static/media/facebook.d2a648dd.png","height":24,"width":24,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAtUlEQVR42jWPvQ3CMBSEXVDRUxGRJZCgYgAWgCQSCEZAAnsGOjpGYAMUO2IBdohs2AFRYb6XH0ufnn13OttKlvY2Nd4VOtjMBLthv9XeJa0ZqoTDCzEabyPhnw5O5lv7MlUmuAKiDo35PNX3IfMgYVhLfQ6RENgz4pz9t9NyhZhJJcYHZsfwGGBcIaKvaOAK39wpXGAB/XsKAlVKqO4qbzQuOUsArex/Ysewx5zCiMCOOVFKqT83zZ5w/3c/FwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/icons/whatsapp.png
/* harmony default export */ const whatsapp = ({"src":"/_next/static/media/whatsapp.cbf8e963.png","height":20,"width":21,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAsUlEQVR42j2OsQ3CMBBFrwCJRViAik2omYDSzgIsQJMKJDoKIiixU0eiYgVb2YBIgESQeZdEifRzX+f3vy362eCXNvqHif6LnvjcBD9DIvwWLBobXDKonz4BXlGXrmx0Hxtuc/zdRKDo3kAaWAvpH6Yx4TIhXeA1nYbGowIvTZHILddxsEXV0LBXoBxTPST4je7QSlgUKPUtnVoAnWckAO6EOTBLwJbqhkfustpPs9rLH1BdrcVUMlOoAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/icons/youtube.png
/* harmony default export */ const youtube = ({"src":"/_next/static/media/youtube.99317e7f.png","height":24,"width":24,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAeUlEQVR42o2PwQ2AIAxFGU5PugJn2aCcjLtoPDJAuwwsIj6CxqskL/T3l5/ifp1YNMRiSbKe1Dt3kmJLN7OOUKVoZahKthoB3RgcTQ809YKZhLVrwHO88PIMED1Rbz1JG95FYgBh0I1P6/juEYhksbakHRiJgfDrhzfuV3ocyBORgQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/icons/twitter.png
/* harmony default export */ const twitter = ({"src":"/_next/static/media/twitter.e2a353ae.png","height":20,"width":25,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAiUlEQVR42mMof7ArsfzBTkkGKADyV1U83P2/4sHu3UAczQDkLAIKPgdyYssf7goB4v9A/n+gOAh7ARXsaqiACgAlQPgPlP2s9P4uLgagTiWgwCuIrl2/gfhH+QOwgoUMMAAUTAHi31C7gXjX1fL7u4ShjtrpDJRcDZT4C9T1Big5u/LBLgGog5kBT7hzh/lHjGsAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/icons/instagram.png
/* harmony default export */ const instagram = ({"src":"/_next/static/media/instagram.4188aac7.png","height":20,"width":20,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAnElEQVR42i2PwQ3DIBAEKcqSU0hcC5SSDiK5hKMVO4GH80aWCMqLzNp+rO5ubwd0zqc4+WxryLGGFLtE33yOb5/s7hiWkKz7UzvhSm2AD+rLKX0tZ+iReYB+0v/wvk40VAnZBswP5IZu+PqmEzifRqI3wgopXI4AZsXsaCasxchixhfYFFgxGCQr1F3AFViczlQD2YIWUtLJBmjTH2Xgt3aP4cf6AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/layout/Footer/BrandDetails.tsx












function BrandDetails() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col items-center md:items-start",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(LogoComponent/* default */.Z, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "flex flex-col gap-4 items-center md:items-start list-none mt-8 text-offWhite text-lg",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        className: "flex flex-row items-center gap-3 justify flex-wrap md:flex-nowrap justify-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: icons_location,
                                alt: "",
                                height: 40,
                                width: 40,
                                objectFit: "contain"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "VFN House, behind Federal Ministry of Agriculture, GRA Osogbo, Osun State"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        className: "flex flex-row items-center gap-3 flex-wrap md:flex-nowrap justify-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: call,
                                alt: ""
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "+2348134730893"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        className: "flex flex-row items-center gap-3 flex-wrap md:flex-nowrap justify-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: email,
                                alt: ""
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "break-all",
                                children: "valuefemalenetwork@gmail.com"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        className: "flex flex-row items-center gap-5 mt-5",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "https://www.facebook.com/ValueFemaleNetwork/",
                                target: "_blank",
                                rel: "noreferrer",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: facebook,
                                    alt: "Facebook"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "https://wa.me/+2348134730893/",
                                target: "_blank",
                                rel: "noreferrer",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: whatsapp,
                                    alt: "Whatsapp"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "https://www.youtube.com/channel/UCyxlejXeVFTUuoM_Lt15Lzw",
                                target: "_blank",
                                rel: "noreferrer",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: youtube,
                                    alt: "Youtube"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "https://twitter.com/ValueFemaleNet",
                                target: "_blank",
                                rel: "noreferrer",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: twitter,
                                    alt: "Twitter"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "https://www.instagram.com/valuefemalenetwork_/",
                                target: "_blank",
                                rel: "noreferrer",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: instagram,
                                    alt: "Instagram"
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const Footer_BrandDetails = (BrandDetails);

;// CONCATENATED MODULE: ./components/layout/Footer/Posts.tsx


function Posts() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col items-center md:items-start text-offWhite ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                className: "mt-0 mb-0 text-2xl font-[Montserrat] font-bold",
                children: "Latest posts"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "flex flex-col gap-4 items-center md:items-start list-none mt-12 text-offWhite text-lg",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        className: "flex flex-col gap-1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Care for Women"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-sm text-lightSuccess",
                                children: "May 20, 2021."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        className: "flex flex-col gap-1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Care for Women"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-sm text-lightSuccess",
                                children: "May 20, 2021."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        className: "flex flex-col gap-1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Care for Women"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-sm text-lightSuccess",
                                children: "May 20, 2021."
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const Footer_Posts = (Posts);

;// CONCATENATED MODULE: ./components/layout/Footer/Projects.tsx


function Projects() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col items-center md:items-start text-offWhite ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                className: "mt-0 mb-0 text-2xl font-[Montserrat] font-bold",
                children: "Our Projects"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "flex flex-col gap-4 items-center md:items-start list-none mt-12 text-offWhite text-lg",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: "Boys Promote Equality"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: "Women in Diaspora."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: "Girl Child Education."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: "Boys Promote Equality"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: "Women in Diaspora."
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const Footer_Projects = (Projects);

;// CONCATENATED MODULE: ./components/layout/Footer/QuickLinks.tsx



function QuickLinks() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col items-center md:items-start text-offWhite ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                className: "mt-0 mb-0 text-2xl font-[Montserrat] font-bold",
                children: "Quick Links"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "flex flex-col gap-4 items-center md:items-start list-none mt-12 text-offWhite text-lg",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "hover:text-lightSuccess",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/",
                            children: "Home"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "hover:text-lightSuccess",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/#about",
                            children: "About Us"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "hover:text-lightSuccess",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/#contact",
                            children: "Contact"
                        })
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const Footer_QuickLinks = (QuickLinks);

;// CONCATENATED MODULE: ./components/layout/Footer/Footer.tsx









function Footer() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 pt-16 pb-16 pl-[3vw] pr-[3vw] bg-dark justify-items-center md:justify-items-start gap-20 ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Footer_BrandDetails, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Footer_Projects, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Footer_QuickLinks, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Footer_Posts, {})
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("aside", {
                className: "pl-[3vw] pr-[3vw] pt-9 pb-9 bg-[#E5E5E5] flex flex-row flex-wrap gap-5 justify-center md:justify-between font-[Montserrat] font-semibold",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center gap-[5px]",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: copyright,
                                alt: ""
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                children: [
                                    new Date().getFullYear(),
                                    " All Rights Reserved"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row items-center gap-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "#",
                                children: "Privacy Policy"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "bg-dark h-full w-[3px]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "#",
                                children: "Terms and Conditions"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const Footer_Footer = (Footer);


/***/ }),

/***/ 9600:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layout_LogoComponent)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/brand/logo.png
/* harmony default export */ const logo = ({"src":"/_next/static/media/logo.336bc3ef.png","height":88,"width":88,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA1UlEQVR42lWPWwsBURSF5+/4q4pc4kkZJCnXeOLpjJBL7rfk0UwzpnGZOWJOWM6ZUNbTbn+rvdaWhAD47NFQOeRzzMhl2WXQJ2L3g2a1YunJBJzpBBxCi0VxbDYsz3Tp94gaDuJxpS4+elDH1WIROIu5IhmZFKObFU4tgutuC7pe4tztgC4XMMtFJhlpmYnlTVM5aOPcbuFu6HDmM5glbuCZihaPgst93m94Mdeb1UhIdCJeyUOpYKmhAOzpGPZ4hH3AD7Nes/4+4blEl5NMT8lMXP3CN+bTyxniGQDwAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/layout/LogoComponent.tsx





function LogoComponent() {
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: "/",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-row items-center gap-2 cursor-pointer",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: logo,
                    alt: "Logo",
                    width: 50,
                    height: 50
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "max-w-[151px] font-bold uppercase text-secondary",
                    children: "Value female Network"
                })
            ]
        })
    });
}
/* harmony default export */ const layout_LogoComponent = (LogoComponent);


/***/ }),

/***/ 6114:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _public_icons_menu_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5136);
/* harmony import */ var _reusable_MenuComponent_MenuComponent__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1160);
/* harmony import */ var _LogoComponent__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9600);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_reusable_MenuComponent_MenuComponent__WEBPACK_IMPORTED_MODULE_5__]);
_reusable_MenuComponent_MenuComponent__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







function Navbar() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
        className: "pl-[3vw] pr-[3vw] pt-6 pb-5 shadow-sm",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex flex-row flex-wrap items-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mr-auto",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        href: "/",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_LogoComponent__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex-row items-center gap-10 hidden lg:flex",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "/#about",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "font-bold hover:text-success cursor-pointer",
                                children: "About Us"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "/#contact",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "font-bold hover:text-success cursor-pointer",
                                children: "Contact Us"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "/#join-us",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "primaryButton",
                                children: "Join Us"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "lg:hidden relative cursor-pointer",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_reusable_MenuComponent_MenuComponent__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        button: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "menu",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                src: _public_icons_menu_png__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                                alt: "Menu"
                            })
                        }),
                        links: [
                            {
                                label: "About Us",
                                href: "/#about"
                            },
                            {
                                label: "Event and News",
                                href: "/#events"
                            },
                            {
                                label: "Contact Us",
                                href: "/#contact"
                            },
                            {
                                label: "Join Us",
                                href: "/#join-us"
                            }, 
                        ]
                    })
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Navbar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1160:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1185);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_1__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const MyLink = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_3__.forwardRef)((props, ref)=>{
    let { href , children , ...rest } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
        href: href,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
            ref: ref,
            ...rest,
            children: children
        })
    });
});
MyLink.displayName = "MyLink";
function MenuComponent({ button , links  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Menu, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Menu.Button, {
                children: button
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Menu.Items, {
                className: "absolute shadow-lg right-0 w-[200px] p-5 z-10 bg-white flex-col flex gap-5",
                children: links?.map((link)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Menu.Item, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MyLink, {
                            href: link.href,
                            children: link.label
                        })
                    }, link.href))
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MenuComponent);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;