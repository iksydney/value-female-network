import React from 'react';

function Naira() {
	return <>₦</>;
}

export default Naira;
